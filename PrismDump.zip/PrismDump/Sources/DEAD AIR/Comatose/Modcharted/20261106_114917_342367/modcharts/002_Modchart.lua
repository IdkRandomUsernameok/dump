-- Decompiled with Potassium's decompiler.

game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local CharacterSprite = require(ReplicatedStorage.Modules.Main.CharacterSprite);
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;

local function stopNote(p5: boolean) -- Line: 11
    -- upvalues: u1 (ref)
    for _, v in u1.Notes do
        v.cancelMovement = p5;
    end;

    for _, v in u1.UnspawnedNotes do
        v.cancelMovement = p5;
    end;
end;

local u6 = {
    Right = {
        alt = "alt-Right",
        normal = "downright"
    },
    Right2 = {
        alt = "alt-Right",
        normal = "downright"
    },
    Left2 = {
        alt = "alt-Left",
        normal = "leftup"
    },
    Left = {
        alt = "alt-Left",
        normal = "leftup"
    },
    Square = {
        alt = "alt-Up",
        normal = "leftup"
    },
    Up = {
        alt = "alt-Up",
        normal = "leftup"
    },
    Down = {
        alt = "alt-Down",
        normal = "downright"
    }
};

return {
    onCreate = function() -- Line: 31, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), CharacterSprite (copy), u3 (ref), u4 (ref)
        u1 = shared.getApi();
        u1.setProperty("camZooming", false);
        u2 = CharacterSprite.new(script.BG.BoiledOne, -90, u1.Game, 2.11328125, false, Vector2.new(1, 1));
        u2:addAnimations({ "alt-idle", "idle" }, 30, true, false);
        u2:addAnimations({ "alt-Down", "alt-Left", "alt-Right", "alt-Up" }, 30, false, false);
        u2:addDirectionalAnimations({ "Down", "Right" }, "downright", 30, false);
        u2:addDirectionalAnimations({ "Left", "Up" }, "leftup", 30, false);
        u2.spr.alpha = 0;
        u2:play("downright");
        u3 = script.Red:Clone();
        u3.Parent = u1.Overlay;
        u4 = script.BG:Clone();
        u4.Parent = u1.Underlay;
    end,

    onStepHit = function(p7) -- Line: 52, Name: onStepHit
        -- upvalues: u2 (ref), u3 (ref), u1 (ref)
        if p7 == 64 then
            u2.spr.alpha = 1;
        end;

        if p7 ~= 462 then
            if p7 == 466 then
                u3.Visible = false;

                for _, v in u1.Notes do
                    v.cancelMovement = false;
                end;

                for _, v in u1.UnspawnedNotes do
                    v.cancelMovement = false;
                end;
            end;

            return;
        end;

        u3.Visible = true;
        u3.BackgroundTransparency = 0.6;

        for _, v in u1.Notes do
            v.cancelMovement = true;
        end;

        for _, v in u1.UnspawnedNotes do
            v.cancelMovement = true;
        end;
    end,

    onPlayerNoteHit = function(p8) -- Line: 67, Name: onPlayerNoteHit
        -- upvalues: u2 (ref), u6 (copy)
        u2:play(p8.rawData[4] == "Alt Animation" and u6[p8.dir].alt or u6[p8.dir].normal, true);
    end,

    onEvent = function(p9, p10, p11) -- Line: 71, Name: onEvent
        -- upvalues: u2 (ref)
        if p9 == "Black Fade" then
            u2.spr.visible = tostring(p10) ~= "True";
        end;

        if p9 == "Play Animation" and tostring(p10) == "idle" then
            u2:play("idle", true);
        end;
    end,

    onClear = function() -- Line: 81, Name: onClear
        -- upvalues: u4 (ref), u3 (ref), u2 (ref)
        for _, v in { u4, u3, u2 } do
            if v then
                v:Destroy();
            end;
        end;
    end
};