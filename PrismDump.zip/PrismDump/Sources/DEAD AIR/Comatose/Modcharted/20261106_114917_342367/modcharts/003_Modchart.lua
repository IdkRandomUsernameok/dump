-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local CacheService = require(ReplicatedStorage.Modules.Main.CacheService);
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = { "Shelter", "Big Eater" };

return {
    onCreate = function() -- Line: 16, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), u4 (ref), CacheService (copy), u3 (ref), u5 (copy)
        u1 = shared.getApi();
        u1.doMiddlescroll(false);
        u1.setProperty("cams.cameraBeat", 0);
        u2 = u1.songData.SongName;
        u4 = script.TitleCards:Clone();
        u4.Parent = u1.Overlay;
        u4.ZIndex = 10;

        for _, descendant in u4:GetDescendants() do
            if descendant:IsA("ImageLabel") then
                CacheService.cacheImage(descendant.Image);
            end;
        end;

        u3 = script.Black:Clone();
        u3.Parent = u1.Underlay;

        if table.find(u5, u2) then
            u3.BackgroundTransparency = 1;
        end;

        if u2 == "Comatose" or u2 == "Purple Comatose" then
            u4.Comatose.ImageTransparency = 0;
        end;

        for _, v in { u1.HUD.HPBar.Player1, u1.HUD.HPBar.Player2, u1.HUD.TimeBar } do
            v.Visible = false;
        end;
    end,

    preCreate = function(p6) -- Line: 47, Name: preCreate
        -- upvalues: u5 (copy)
        if not table.find(u5, p6.songData.SongName) then
            p6.setSetting(nil, "DisableMapMidsong", true);
            p6.setSetting(nil, "HideCharacters", true);
            p6.setSetting(nil, "HideLobby", true);
        end;
    end,

    onSongStart = function() -- Line: 55, Name: onSongStart
        -- upvalues: u2 (ref), u4 (ref)
        if u2 == "Fancy Island" then
            u4.FancyIsland.ImageTransparency = 0;
        end;
    end,

    onBeatHit = function(p7) -- Line: 61, Name: onBeatHit
        -- upvalues: u2 (ref), TweenService (copy), u4 (ref), u1 (ref)
        if u2 == "Under The Tree" then
            if p7 == 8 then
                TweenService:Create(u4.UnderTheTree, TweenInfo.new(2.4 / u1.playbackRate), {
                    ImageTransparency = 0
                }):Play();

                return;
            end;

            if p7 == 16 then
                TweenService:Create(u4.UnderTheTree, TweenInfo.new(2.4 / u1.playbackRate), {
                    ImageTransparency = 1
                }):Play();
            end;
        end;
    end,

    onStepHit = function(p8) -- Line: 71, Name: onStepHit
        -- upvalues: u2 (ref), TweenService (copy), u4 (ref), u1 (ref), u3 (ref)
        if u2 == "Comatose" or u2 == "Purple Comatose" then
            if p8 == 16 then
                TweenService:Create(u4.Comatose.Credits, TweenInfo.new(0.4 / u1.playbackRate), {
                    ImageTransparency = 0
                }):Play();
            elseif p8 == 36 then
                TweenService:Create(u4.Comatose.Based, TweenInfo.new(0.4 / u1.playbackRate), {
                    ImageTransparency = 0
                }):Play();
            elseif p8 == 48 then
                u4.Comatose.ImageTransparency = 1;
                u4.Comatose.Credits.ImageTransparency = 1;
                u4.Comatose.Based.ImageTransparency = 1;
            end;
        end;

        if u2 == "Fancy Island" then
            if p8 == 16 then
                TweenService:Create(u4.FancyIslandCredits, TweenInfo.new(0.6 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                    ImageTransparency = 0.3
                }):Play();
                TweenService:Create(u4.FancyIslandCredits, TweenInfo.new(0.7 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                    Position = UDim2.fromScale(0.5, 0.5)
                }):Play();
            elseif p8 == 56 then
                local v9 = TweenService:Create(u4.FancyIsland, TweenInfo.new(1.3 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                    Position = UDim2.fromScale(-0.5, 0.5)
                });
                TweenService:Create(u4.FancyIslandCredits, TweenInfo.new(1.3 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                    Position = UDim2.fromScale(1.5, 0.5)
                }):Play();
                v9:Play();
                v9.Completed:Connect(function() -- Line: 92
                    -- upvalues: u4 (ref)
                    u4.FancyIsland.Visible = false;
                    u4.FancyIslandCredits.Visible = false;
                end);
            end;
        end;

        if u2 == "Shelter" then
            if p8 == 873 then
                u3.BackgroundTransparency = 0;
                u4.Shelter.First.TextTransparency = 0;
            elseif p8 == 888 then
                TweenService:Create(u4.Shelter.Second, TweenInfo.new(1 / u1.playbackRate, Enum.EasingStyle.Linear), {
                    TextTransparency = 0
                }):Play();
            elseif p8 == 902 then
                u4.Shelter.First.Visible = false;
                u4.Shelter.Second.Visible = false;
            end;
        end;

        if u2 == "Remembered" and p8 == 192 then
            u4.Remembered.ImageTransparency = 0;
            TweenService:Create(u4.Remembered, TweenInfo.new(1.2 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                Position = UDim2.fromScale(0.5, 0.5)
            }):Play();
            task.delay(3.6 / u1.playbackRate, function() -- Line: 115
                -- upvalues: u1 (ref), TweenService (ref), u4 (ref)
                local v10 = u1.Settings.Downscroll and UDim2.fromScale(0.5, 1.2) or UDim2.fromScale(0.5, -0.2);
                TweenService:Create(u4.Remembered, TweenInfo.new(1.2 / u1.playbackRate, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
                    Position = v10
                }):Play();
                task.wait(1.2 / u1.playbackRate);
                u4.Remembered.ImageTransparency = 1;
            end);
        end;
    end,

    onClear = function() -- Line: 125, Name: onClear
        -- upvalues: u4 (ref), u3 (ref)
        for _, v in { u4, u3 } do
            if v then
                v:Destroy();
            end;
        end;
    end
};