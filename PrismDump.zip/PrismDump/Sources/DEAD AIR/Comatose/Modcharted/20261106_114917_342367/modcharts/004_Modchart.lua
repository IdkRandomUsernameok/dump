-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
require(game:GetService("ReplicatedStorage").Modules.Main.Sprite);
require(game:GetService("ReplicatedStorage").Modules.Main.VarTweener);
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = {};
local u5 = nil;
local u6 = false;

local function createCircle() -- Line: 12
    -- upvalues: u1 (ref), u6 (ref), u4 (copy), TweenService (copy)
    local Frame = Instance.new("Frame");
    Frame.BackgroundTransparency = 1;
    Frame.Size = UDim2.fromScale(0, 0);
    Frame.Position = UDim2.new(0.5, 0, 0.5, 0);
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Parent = u1.Game;
    Frame.ZIndex = -100;
    Frame.Visible = u6;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.new(1, 1, 1);
    UIStroke.Thickness = 5;
    UIStroke.Parent = Frame;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0.5, 0);
    UICorner.Parent = Frame;
    table.insert(u4, Frame);
    local v7 = TweenService:Create(Frame, TweenInfo.new(5 / u1.playbackRate, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
        Size = UDim2.fromScale(1.5, 2.6)
    });
    v7:Play();
    v7.Completed:Connect(function() -- Line: 35
        -- upvalues: u4 (ref), Frame (copy)
        local table_find_ret = table.find(u4, Frame);

        if table_find_ret then
            table.remove(u4, table_find_ret);
        end;

        Frame:Destroy();
    end);
end;

function circleVisibility(p8: boolean)
    -- upvalues: u1 (ref), u4 (copy), u6 (ref)
    if u1.Settings.CameraFlash then
        for _, v in u4 do
            v.Visible = p8;
        end;

        u6 = p8;
    end;
end;

local u9 = {
    [192] = "You will see me, and I will see you too.",
    [260] = "When you wake up, you will not be able to move any part of your body.",
    [300] = "But it wasn\'t my fault.",
    [388] = "Why did you leave me here?",
    [464] = "No evil shall befall you, and no plague shall come near your dwelling.",
    [500] = "I know you heard me.",
    [532] = "i cant see this paper. i have no hand.",
    [800] = "It was all your fault."
};

return {
    onCreate = function() -- Line: 63, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), u3 (ref)
        u1 = shared.getApi();
        u2 = script.Scanline:Clone();
        u2.Parent = u1.Overlay;
        u3 = script.RedPulse:Clone();
        u3.Parent = u1.Overlay;
    end,

    onStepHit = function(p10) -- Line: 73, Name: onStepHit
        -- upvalues: u9 (copy), u1 (ref), u5 (ref), createCircle (copy)
        for i, v in u9 do
            if p10 == i then
                u1.setTitle(v);
            end;
        end;

        if u5 then
            if not u1.Settings.CameraFlash then
                return;
            end;

            createCircle();
        end;

        if p10 == 150 then
            u5 = true;
        elseif p10 == 320 then
            u5 = false;
        end;

        if p10 == 188 then
            u1.tweenProperty("camGame.zoom", 1.3, 0.5, "easeInOut");
            u1.tweenProperty("camHUD.zoom", 1.3, 0.5, "easeInOut");
        end;

        if p10 == 256 then
            circleVisibility(false);
        elseif p10 == 260 then
            circleVisibility(true);
        end;

        if p10 == 192 then
            u1.setProperty("camZooming", true);
            circleVisibility(true);

            return;
        end;

        if p10 == 320 then
            u1.setProperty("camZooming", false);
            circleVisibility(false);

            return;
        end;

        if p10 == 464 then
            u1.setProperty("camZooming", true);

            return;
        end;

        if p10 == 256 or p10 >= 192 and (p10 <= 319 and p10 % 4 == 0) then
            u1.triggerEvent("Screen Shake", "0.005", "0.005");

            return;
        end;

        if p10 >= 192 and (p10 <= 255 and p10 % 4 == 0) or p10 >= 260 and (p10 <= 319 and p10 % 4 == 0) then
            u1.triggerEvent("Screen Shake", "0.005,3", "0.005,3.2");

            return;
        end;

        if p10 >= 594 and p10 <= 724 then
            u1.triggerEvent("Screen Shake", "0.005,1.5", "0.005,1.3");

            return;
        end;

        if p10 >= 792 and p10 <= 919 then
            u1.triggerEvent("Screen Shake", "0.005,4.5", "0.005,4");

            return;
        end;

        if p10 ~= 920 then
            if p10 == 336 then
                u1.setProperty("camZooming", false);
            end;

            return;
        end;

        u1.triggerEvent("Afternight Game Alpha", 0, 0);
        u1.triggerEvent("Screen Shake", "0.005", "0.005");
    end,

    onBeatHit = function(p11) -- Line: 126, Name: onBeatHit
        -- upvalues: u1 (ref), u3 (ref), TweenService (copy)
        if p11 >= 116 and p11 <= 146 then
            if not u1.Settings.CameraFlash then
                return;
            end;

            u3.BackgroundTransparency = 0.7;
            TweenService:Create(u3, TweenInfo.new(0.5 / u1.playbackRate, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
                BackgroundTransparency = 1
            }):Play();
        end;
    end,

    onNoteMiss = function() -- Line: 134, Name: onNoteMiss
        -- upvalues: u1 (ref)
        u1.triggerEvent("Afternight Game Alpha", 0.4, 0);
        u1.triggerEvent("Afternight Game Alpha", 1, 1);
    end,

    onClear = function() -- Line: 139, Name: onClear
        -- upvalues: u2 (ref), u4 (copy)
        if u2 then
            u2:Destroy();
        end;

        for _, v in u4 do
            if v then
                v:Destroy();
            end;
        end;
    end
};