-- Decompiled with Potassium's decompiler.

return {
    Credits = "vladosikos17, data5, Gavinn, pappo, Triky Troy, Icey131, TacoGSucks, Infry, Out_Mance, xyy, funkypopp, Lock_Trap_LT & <i>Jim</i> // Icon by InkBlade",
    Icon = "rbxassetid://124953565590083",
    Artist = "vladosikos17",
    Color = Color3.new(0.686275, 0.176471, 0.184314),
    Weeks = { {
            Name = "Meet The Chezzkids!",
            Songs = { "Under The Tree" }
        }, {
            Name = "The Boiled One",
            Songs = { "Comatose" }
        }, {
            Name = "Lomando",
            Songs = { "Fancy Island" }
        }, {
            Name = "John",
            Songs = { "Big Eater" }
        }, {
            Name = "Jim\'s Computer",
            Songs = { "Shelter" }
        }, {
            Name = "_Boisvert",
            Songs = { "Remembered" }
        }, {
            Name = "Webdriver Torso",
            Songs = { "tmpb2hpbw==" }
        }, {
            Name = "The Zorped One",
            Songs = { "Purple Comatose" }
        } },
    SongIcons = {
        ["Under The Tree"] = "rbxassetid://115617744068583",
        Comatose = "rbxassetid://124953565590083",
        ["Purple Comatose"] = "rbxassetid://74486278280653",
        ["Fancy Island"] = "rbxassetid://125175901094499",
        Shelter = "rbxassetid://72219075699766",
        ["Big Eater"] = "rbxassetid://87650549552875",
        Remembered = "rbxassetid://116971382239519",
        ["tmpb2hpbw=="] = "rbxassetid://76321335364914"
    },
    Colors = {
        Comatose = Color3.new(0.333333, 0, 0),
        ["Under The Tree"] = Color3.new(0, 0.917647, 1),
        Shelter = Color3.new(1, 0.92549, 0.109804),
        ["Big Eater"] = Color3.new(1, 1, 1),
        ["Fancy Island"] = Color3.new(0.380392, 0.380392, 0.380392),
        Remembered = Color3.new(0, 0, 0),
        ["tmpb2hpbw=="] = ColorSequence.new(Color3.new(0, 0, 1), Color3.new(1, 0, 0)),
        ["Purple Comatose"] = Color3.new(0.470588, 0.00392157, 1)
    },
    ExtraCredits = {
        ["Under the Tree"] = {
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        ["Fancy Island"] = {
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        ["tmpb2hpbw=="] = {
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        Remembered = {
            Artist = "Lock Trap ft. vladosikos17",
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        ["Purple Comatose"] = {
            Artist = "xyy",
            Credits = "+ \nCharted by wil"
        },
        ["Big Eater"] = {
            Artist = "vladosikos17 ft. Outmance",
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        Shelter = {
            Artist = "Jim ft. vladosikos17",
            Credits = "+ \nAnimations by spookeryzz",
            Difficulties = {
                Normal = "+ \nCharted by Chloo"
            }
        },
        Comatose = {
            Difficulties = {
                ["Hard (7K)"] = "+ \nCharted by comedy_individual"
            }
        }
    }
};