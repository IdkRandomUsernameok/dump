-- Decompiled with Potassium's decompiler.

local u1 = nil;

return {
    onCreate = function() -- Line: 4, Name: onCreate
        -- upvalues: u1 (ref)
        u1 = shared.getApi();
        u1.triggerEvent("Afternight Fade Underlay", "0.01", "1");
    end
};