-- Decompiled with Potassium's decompiler.

return {
    Credits = "Various Artists // Afternight Charting Team",
    Icon = "rbxassetid://135380235173201",
    ShowWeekNames = true,
    IconPack = "Misc. (Other)",
    Color = ColorSequence.new(Color3.new(0.92549, 0.0196078, 0.705882), Color3.new(0.4, 0.12549, 1)),
    GameIds = {
        ["Sweet Release of Death"] = 8381774868
    },
    Weeks = {
        {
            Name = "RTPN",
            Songs = { "Sustain" }
        },
        {
            Name = "saikoro",
            Songs = { "far in the blue sky..." }
        },
        {
            Name = "nequ",
            Songs = { "crash and burn" }
        },
        {
            Name = "Monstercat",
            Songs = { "Fire", "Shiawase" }
        },
        {
            Name = "DJ Mars",
            Songs = { "Lemon Tree (Lemon Dance)" }
        },
        {
            Name = "Kry.exe",
            Songs = { "Last Wish" }
        },
        {
            Name = "Gentle Stick",
            Songs = { "Ineffabilis" }
        },
        {
            Name = "Creo",
            Songs = { "Challenger", "Dimension" }
        },
        {
            Name = "siromaru",
            Songs = { "Catch the Glory" }
        },
        {
            Name = "AZALI",
            Songs = { "TO DUST THOU SHALT RETURN" }
        },
        {
            Name = "GTA",
            Songs = { "Red Lips (Mendus Remix)" }
        },
        {
            Name = "Kokosei",
            Songs = { "Moonlight (JustDazzel Cover)" }
        },
        {
            Name = "Tatsh",
            Songs = { "Red Zone" }
        },
        {
            Name = "Chroma",
            Songs = { "Dark Sheep", "sink to the deep sea world", "tiny tales continue", "月葬" }
        },
        {
            Name = "Street",
            Songs = { "Sakura Fubuki" }
        },
        {
            Name = "DragonForce",
            Songs = { "Through the Fire and Flames", "Symphony of the Night" }
        },
        {
            Name = "Xtrullor",
            Songs = { "Screamroom" }
        },
        {
            Name = "NightHawk22",
            Songs = { "Isolation", "Animation Warrior Theme" }
        },
        {
            Name = "Deep Rock Galactic OST",
            Songs = { "RUN!", "Axes Out" }
        },
        {
            Name = "Hinkik",
            Songs = { "Ena" }
        },
        {
            Name = "Sydosys",
            Songs = { "ArchangeL", "Partition" }
        },
        {
            Name = "Saruky",
            Songs = { "club2010", "Justicia Dorada" }
        },
        {
            Name = "Waterflame",
            Songs = { "Endgame", "Electroman Adventures" }
        },
        {
            Name = "Shadrow",
            Songs = { "Never Be Alone", "Ghost in the Machine" }
        },
        {
            Name = "PSY",
            Songs = { "Gangnam Style", "Gentleman" }
        },
        {
            Name = "Teminite",
            Songs = { "Come Together Now" }
        },
        {
            Name = "Fall Guys OST",
            Songs = { "Fall \'N\' Roll" }
        },
        {
            Name = "ChaoticCanineCulture",
            Songs = { "You Can\'t Escape Me", "TOO FAR" }
        },
        {
            Name = "Lemon Demon",
            Songs = { "The Ultimate Showdown of Ultimate Destiny", "Two Trucks", "Pizza Heroes" }
        },
        {
            Name = "TANGER",
            Songs = { "BIKE" }
        },
        {
            Name = "DJ SHARPNEL",
            Songs = { "BLUE ARMY", "Over the Fullereneshift", "You Touched The Kore, and Now You\'re Going to Die", "We Luv Lama" }
        },
        {
            Name = "t+pazolite",
            Songs = { "BPM=RT", "Dogbite" }
        },
        {
            Name = "House Of Serpents",
            Songs = { "Ritual" }
        },
        {
            Name = "Battlejuice",
            Songs = { "Dragon Hunt" }
        },
        {
            Name = "Fl00t",
            Songs = { "Eltaw" }
        },
        {
            Name = "Monster Hunter OST",
            Songs = { "Domain of Dust and Desolation" }
        },
        {
            Name = "Earthbound 2012 ~ I Miss You",
            Songs = { "Megalo Strike Back" }
        },
        {
            Name = "The Stupendium",
            Songs = { "Why Did I Say Okie Doki?", "The Fine Print", "The Most Fashionable Faction", "AD INFINITUM" }
        },
        {
            Name = "Sugary Spire OST",
            Songs = { "Sweet Release of Death" }
        },
        {
            Name = "Parry Gripp",
            Songs = { "Raining Tacos" }
        },
        {
            Name = "eXceed3rd-JADE PENETRATE-BLACK PACKAGE OST",
            Songs = { "Intersect Thunderbolt (Remix)" }
        },
        {
            Name = "Eltorro64Rus",
            Songs = { "Warp Zone" }
        },
        {
            Name = "Bayonetta OST",
            Songs = { "Fly Me to The Moon (∞ Climax Mix)" }
        },
        {
            Name = "mafumafu",
            Songs = { "I wanna be a girl", "Yume no Mata Yume", "Non-breath oblige", "[Lycoris]" }
        },
        {
            Name = "Tawaci",
            Songs = { "NONE OF THIS CONCERNS YOU" }
        },
        {
            Name = "noodilith",
            Songs = { "PREPARE YOUR DEFENSEZ" }
        },
        {
            Name = "Clappers46",
            Songs = { "Know Your Place" }
        },
        {
            Name = "ImPaper",
            Songs = { "MONTAGEM XONADA (ImPaper Mix)" }
        },
        {
            Name = "Solaris",
            Songs = { "song that plays when you encounter a caterpillar" }
        },
        {
            Name = "beansclub",
            Songs = { "around and around", "hanshin", "quietly, quietly die" }
        },
        {
            Name = "Lappy",
            Songs = { "Game On, Beats High" }
        },
        {
            Name = "Helltaker OST",
            Songs = { "Titanium" }
        },
        {
            Name = "atsuover",
            Songs = { "storm", "PAST MY PRIME TIME", "OVERTiME", "GOOD ENOUGH!" }
        },
        {
            Name = "ivycomb",
            Songs = { "ANTIHUMAN", "SLUGCAT PINBALL", "INFAMOUS" }
        },
        {
            Name = "SMJ",
            Songs = { "MEET.YOUR.TORMENTOR", "SPIRIT KILLERS", "A SPECIAL TREE.", "PRETTY STARS" }
        },
        {
            Name = "Woon OST",
            Songs = { "Dark Woon" }
        },
        {
            Name = "Shappy",
            Songs = { "Kratos" }
        },
        {
            Name = "Danimal Cannon",
            Songs = { "Long Live The New Fresh (Live)" }
        },
        {
            Name = "Kubbi",
            Songs = { "Cascade" }
        },
        {
            Name = "zxppy / zeta",
            Songs = { "Daydreamer", "Uncertain" }
        },
        {
            Name = "Musical Masterpiece",
            Songs = { "M-A" }
        },
        {
            Name = "Geometry Dash OST",
            Songs = { "Geometrical Dominator" }
        },
        {
            Name = "Super Meat Boy Forever OST",
            Songs = { "Title Screen" }
        },
        {
            Name = "michi",
            Songs = { "in my room" }
        },
        {
            Name = "Terraria: Wrath of the Gods Mod OST",
            Songs = { "TWISTED GARDEN" }
        },
        {
            Name = "bbpanzu",
            Songs = { "BANG BANG BANG" }
        },
        {
            Name = "Good Kid",
            Songs = { "Nomu", "Summer" }
        },
        {
            Name = "Five Nights at Frickbear\'s 3 OST",
            Songs = { "2MUCH2BEAR" }
        },
        {
            Name = "Sparkygan",
            Songs = { "Komodo Dragon (Sparky Mix)", "Schoolhouse Invasion" }
        },
        {
            Name = "Jamie Paige",
            Songs = { "Dyad" }
        },
        {
            Name = "Doin",
            Songs = { "Pine Nut" }
        },
        {
            Name = "RundownSD",
            Songs = { "NOOB KING" }
        },
        {
            Name = "Sheet Music Boss",
            Songs = { "RUSH E" }
        },
        {
            Name = "nicopatty",
            Songs = { "change my mind" }
        },
        {
            Name = "Tobu",
            Songs = { "Candyland" }
        },
        {
            Name = "joolie",
            Songs = { "detach", "silly", "4drift" }
        },
        {
            Name = "AXIE",
            Songs = { "TERRIBLE THINGS" }
        },
        {
            Name = "Zenless Zone Zero OST",
            Songs = { "Burning Desires", "Come Alive" }
        }
    },
    ExtraCredits = {
        ["TWISTED GARDEN"] = {
            Artist = "ENNWAY! & Heart Plus Up!",
            Credits = "Lucile Karma, Moonburn, ENNWAY! & Heart Plus Up! // Charted by KrystalKlears & RhysRJJ"
        },
        ["TERRIBLE THINGS"] = {
            Artist = "AXIE",
            Credits = "AXIE // Charted by PlushtrapDev"
        },
        ["Wild West"] = {
            Artist = "DJ Awesome, NicoisNXXT, PAPERJAMZ, michimoomo & MrSteeletrap",
            Credits = "DJ Awesome, NicoisNXXT, PAPERJAMZ, michimoomo & MrSteeletrap // Charted by Kappy"
        },
        ["What Goes Up"] = {
            Artist = "DJ Awesome, NicoisNXXT, PAPERJAMZ, michimoomo & MrSteeletrap",
            Credits = "DJ Awesome, NicoisNXXT, PAPERJAMZ, michimoomo & MrSteeletrap // Charted by Kappy"
        },
        ["Come Alive"] = {
            Artist = "Lei Sheng, Philip Strand, Zheng Shiwei & InChaos",
            Credits = "miHoYo, Li Zhenyu, Sān-Z STUDIO, Lei Sheng, Philip Strand, Zheng Shiwei & InChaos // Charted by RhysRJJ"
        },
        ["Burning Desires"] = {
            Artist = "Lei Sheng, Philip Strand, Zheng Shiwei & InChaos",
            Credits = "miHoYo, Li Zhenyu, Sān-Z STUDIO, Lei Sheng, Philip Strand, Zheng Shiwei & InChaos // Charted by RhysRJJ"
        },
        ["2MUCH2BEAR"] = {
            Artist = "RedTV53",
            Credits = "SpookyRick & RedTV53 // Charted by Cqmbo"
        },
        Candyland = {
            Artist = "Tobu",
            Credits = "Tobu // Charted by HuniLuxe"
        },
        ["4drift"] = {
            Artist = "joolie",
            Credits = "joolie // Charted by RoundCat"
        },
        detach = {
            Artist = "joolie",
            Credits = "joolie // Charted by RoundCat"
        },
        silly = {
            Artist = "joolie",
            Credits = "joolie // Charted by RoundCat"
        },
        ["NOOB KING"] = {
            Artist = "RundownSD",
            Credits = "RundownSD // Charted by vyzon"
        },
        ["change my mind"] = {
            Artist = "nicopatty ft. tropes",
            Credits = "nicopatty & tropes // Charted by vyzon"
        },
        ["RUSH E"] = {
            Artist = "Sheet Music Boss",
            Credits = "Sheet Music Boss // Charted by maris_a"
        },
        Shiawase = {
            Artist = "Dion Timmer",
            Credits = "Dion Timmer & Monstercat // Charted by maris_a"
        },
        ["月葬"] = {
            Artist = "Chroma & rintaro soma",
            Credits = "Chroma & rintaro soma // Charted by puprelic"
        },
        ["tiny tales continue"] = {
            Artist = "Chroma",
            Credits = "Chroma // Charted by HuniLuxe"
        },
        ["Pine Nut"] = {
            Artist = "Doin",
            Credits = "Doin // Charted by waxatak"
        },
        ["Komodo Dragon (Sparky Mix)"] = {
            Artist = "Sparkygan",
            Credits = "Sparkygan // Charted by FluffyReese\nBackground by popdoo323"
        },
        ["Schoolhouse Invasion"] = {
            Artist = "Sparkygan",
            Credits = "Sparkygan // Charted by FluffyReese\nBackground by redx_dreemurr"
        },
        Dyad = {
            Artist = "Jamie Paige",
            Credits = "Jamie Paige // Charted by HuniLuxe"
        },
        ["Justicia Dorada"] = {
            Artist = "Saruky",
            Credits = "Saruky // Charted by HuniLuxe"
        },
        club2010 = {
            Artist = "Saruky",
            Credits = "Saruky // Charted by HuniLuxe"
        },
        Summer = {
            Artist = "Good Kid",
            Credits = "Good Kid // Charted by ResurrectionSolar"
        },
        Nomu = {
            Artist = "Good Kid",
            Credits = "Good Kid // Community Chart by Quik"
        },
        ["BANG BANG BANG"] = {
            Artist = "bbpanzu ft. starxrayne & JamsDX",
            Credits = "bbpanzu, starxrayne & JamsDX // Icon by InkBlade",
            Difficulties = {
                Normal = "+ \nCharted by Kappy",
                Medium = "+ \nCommunity Chart by NeLe",
                Hard = "+ \nCharted by Kappy",
                ["Hard (ALT)"] = "+ \nCommunity Chart by NeLe",
                Expert = "+ \nCharted by RhysRJJ"
            }
        },
        ["MONTAGEM XONADA (ImPaper Mix)"] = {
            Artist = "ImPaper",
            Credits = "ImPaper, MXZI, DJ SAMIR & DJ JAVI26 // Charted by RhysRJJ"
        },
        ["in my room"] = {
            Artist = "michi",
            Credits = "michi // Charted by thebluefrawog"
        },
        ["Title Screen"] = {
            Artist = "Team Meat",
            Credits = "Team Meat & Planet Ridiculon // Charted by Smidgy"
        },
        ["Long Live The New Fresh (Live)"] = {
            Artist = "Danimal Cannon",
            Credits = "Danimal Cannon // Charted by TRFerret"
        },
        ["Geometrical Dominator"] = {
            Artist = "Waterflame",
            Credits = "RobTop Games & Waterflame // Charted by TRFerret"
        },
        Daydreamer = {
            Artist = "zxppy / zeta",
            Credits = "zxppy / zeta // Charted by vyzon"
        },
        Uncertain = {
            Artist = "zxppy / zeta",
            Credits = "zxppy / zeta // Charted by vyzon"
        },
        ["M-A"] = {
            Artist = "Musical Masterpiece",
            Credits = "Musical Masterpiece // Charted by Rubignius"
        },
        Cascade = {
            Artist = "Kubbi",
            Credits = "Kubbi // Charted by TRFerret"
        },
        Ritual = {
            Artist = "House Of Serpents ft. Battlejuice",
            Credits = "House Of Serpents & Battlejuice // Charted by thebluefrawog"
        },
        ["Warp Zone"] = {
            Artist = "Eltorro64Rus",
            Credits = "Eltorro64Rus // Charted by catgirlsequence"
        },
        Kratos = {
            Artist = "Shappy",
            Credits = "Shappy // Charted by 2ndEdition"
        },
        ["Dragon Hunt"] = {
            Artist = "Battlejuice",
            Credits = "Battlejuice // Charted by thebluefrawog"
        },
        ["quietly, quietly die"] = {
            Artist = "beansclub",
            Credits = "beansclub // Charted by thebluefrawog"
        },
        ["Dark Woon"] = {
            Artist = "Tour De Pizza",
            Credits = "Tour De Pizza & McPig // Charted by KrystalKlears"
        },
        Partition = {
            Artist = "Sydosys",
            Credits = "Sydosys // Charted by catgirlsequence, thebluefrawog, maris_a & Burgerdog"
        },
        ["MEET.YOUR.TORMENTOR"] = {
            Artist = "SMJ",
            Credits = "SMJ & <i>ihazafaceLULZ</i> // Charted by KrystalKlears\nIcon by Llamas\nAnimations by Piza"
        },
        ["SPIRIT KILLERS"] = {
            Artist = "SMJ",
            Credits = "SMJ, <i>Spirit & Scripter</i> // Background by Llamas\nIcon by Llamas",
            Difficulties = {
                Hard = "+ \nCharted by KrystalKlears",
                Normal = "+ \nCharted by Llamas"
            }
        },
        ["A SPECIAL TREE."] = {
            Artist = "SMJ, Maro & Jimmy McPuzzle",
            Credits = "SMJ, Maro, Jimmy McPuzzle, Ori, <i>Rochas313 & 1DashLeaves</i> // Charted by KrystalKlears\nIcon by Llamas\nBackground by SMJ"
        },
        ["PRETTY STARS"] = {
            Artist = "SMJ ft. Lasaga",
            Credits = "SMJ & Lasaga // Charted by KrystalKlears\nIcon by Llamas\nBackground by Llamas"
        },
        ["crash and burn"] = {
            Artist = "nequ & kanz",
            Credits = "nequ & kanz // Charted by thebluefrawog"
        },
        ANTIHUMAN = {
            Artist = "ivycomb ft. Stephanafro",
            Credits = "ivycomb & Stephanafro // Charted by PlushtrapDev"
        },
        ["SLUGCAT PINBALL"] = {
            Artist = "ivycomb",
            Credits = "ivycomb // Charted by Tiel"
        },
        INFAMOUS = {
            Artist = "ivycomb ft. YonKaGor & Stephanafro",
            Credits = "ivycomb, YonKaGor & Stephanafro // Charted by HuniLuxe"
        },
        OVERTiME = {
            Artist = "atsuover",
            Credits = "atsuover // Charted by PlushtrapDev"
        },
        ["PAST MY PRIME TIME"] = {
            Artist = "atsuover",
            Credits = "atsuover // Charted by 2ndEdition"
        },
        storm = {
            Artist = "atsuover",
            Credits = "atsuover // Charted by PlushtrapDev"
        },
        ["GOOD ENOUGH!"] = {
            Artist = "atsuover",
            Credits = "atsuover // Charted by TRFerret"
        },
        ["Fly Me to The Moon (∞ Climax Mix)"] = {
            Artist = "Bart Howard & Helena Noguerra",
            Credits = "SEGA, Platinum Games, Hiroshi Yamaguchi, Bart Howard & Helena Noguerra // Charted by PlushtrapDev"
        },
        ["You Belong To Me"] = {
            Artist = "DJ Awesome",
            Credits = "DJ Awesome // Charted by Kappy"
        },
        ["Light Emitting Diode"] = {
            Artist = "Neko",
            Credits = "Neko // Charted by benmuga"
        },
        ["Game On, Beats High"] = {
            Artist = "Lappy",
            Credits = "Lappy // Background and Lappy Animation by Nak1yosh\nLappy Faces by Travago\nCharted by Aura"
        },
        Titanium = {
            Artist = "Mittsies",
            Credits = "Vanripper & Mittsies // Charted by KrystalKlears"
        },
        ["around and around"] = {
            Artist = "beansclub",
            Credits = "beansclub // Charted by thebluefrawog"
        },
        hanshin = {
            Artist = "beansclub",
            Credits = "beansclub // Charted by thebluefrawog"
        },
        ["song that plays when you encounter a caterpillar"] = {
            Artist = "Solaris",
            Credits = "Solaris // Charted by maybematt_there"
        },
        ["Electroman Adventures"] = {
            Artist = "Waterflame",
            Credits = "Waterflame // Charted by KrystalKlears"
        },
        ["PREPARE YOUR DEFENSEZ"] = {
            Artist = "noodilith & Bergatron",
            Credits = "noodilith & Bergatron // Charted by KrystalKlears\nIcon by Glubbee"
        },
        ["Know Your Place"] = {
            Artist = "Clappers46",
            Credits = "Clappers46 // Icon by InkBlade",
            Difficulties = {
                Hard = "+ \nCharted by ResurrectionSolar",
                ["Hard (ALT)"] = "+ \nCharted by Smidgy",
                Advanced = "+ \nCharted by RhysRJJ"
            }
        },
        ["Raining Tacos"] = {
            Artist = "Parry Gripp",
            Credits = "Parry Gripp // Charted by TRFerret"
        },
        ["I wanna be a girl"] = {
            Artist = "mafumafu",
            Credits = "mafumafu // Charted by Maji"
        },
        ["Yume no Mata Yume"] = {
            Artist = "mafumafu",
            Credits = "mafumafu // Charted by Maji"
        },
        ["[Lycoris]"] = {
            Artist = "mafumafu",
            Credits = "mafumafu // Charted by Maji"
        },
        ["Non-breath oblige"] = {
            Artist = "mafumafu ft. PinocchioP",
            Credits = "PinocchioP, mafumafu & <i>Hatsune Miku</i> // Charted by Maji"
        },
        ["Two Trucks"] = {
            Artist = "Lemon Demon",
            Credits = "Lemon Demon // Charted by comedy_individual"
        },
        ["The Ultimate Showdown of Ultimate Destiny"] = {
            Artist = "Lemon Demon",
            Credits = "Lemon Demon // Charted by KrystalKlears"
        },
        ["Pizza Heroes"] = {
            Artist = "Lemon Demon",
            Credits = "Lemon Demon // Charted by HuniLuxe"
        },
        ["Sweet Release of Death"] = {
            Artist = "PaperKitty",
            Credits = "Sugary Spire Council // Icon by Jakub\nCharted by comedy_individual"
        },
        Sustain = {
            Artist = "RTPN",
            Credits = "RTPN // Charted by wil"
        },
        ["Lemon Tree (Lemon Dance)"] = {
            Artist = "DJ Mars",
            Credits = "DJ Mars // Charted by waxatak"
        },
        Fire = {
            Artist = "Stonebank",
            Credits = "Stonebank & Monstercat // Charted by benmuga"
        },
        ["far in the blue sky..."] = {
            Credits = "<font color=\"#FFDD1F\">saikoro</font>",
            Artist = "saikoro",
            Difficulties = {
                Expert = "+ // Charted by waxatak",
                X_X = "+ // Charted by Carrots"
            }
        },
        ["Last Wish"] = {
            Artist = "Kry.exe ft. Ice",
            Credits = "Kry.exe & Ice",
            Difficulties = {
                Expert = "+ // Charted by jian_awesome",
                Exhausted = "+ // Charted by thebluefrawog",
                Legacy = "+ // Charted by jian_awesome"
            }
        },
        Ineffabilis = {
            Artist = "Gentle Stick ft. M2U",
            Credits = "Gentle Stick & M2U // Charted by jian_awesome"
        },
        Challenger = {
            Artist = "Creo",
            Credits = "Creo // Charted by jian_awesome"
        },
        ["Catch the Glory"] = {
            Artist = "打打だいず & siromaru",
            Credits = "打打だいず & siromaru // Charted by jian_awesome"
        },
        ["TO DUST THOU SHALT RETURN"] = {
            Artist = "tn-shi & AZALI",
            Credits = "tn-shi & AZALI // Charted by jian_awesome"
        },
        ["Red Lips (Mendus Remix)"] = {
            Artist = "GTA ft. Sam Bruno",
            Credits = "GTA & Sam Bruno // Charted by Hydria"
        },
        ["Moonlight (JustDazzel Cover)"] = {
            Artist = "Kokosei (Cover by JustDazzel)",
            Credits = "Kokosei & JustDazzel // Charted by wil"
        },
        ["Red Zone"] = {
            Artist = "Tatsh & NAOKI",
            Credits = "Tatsh & NAOKI // Charted by waxatak"
        },
        ["The Most Fashionable Faction"] = {
            Artist = "The Stupendium",
            Credits = "The Stupendium // Charted by TRFerret"
        },
        ["Why Did I Say Okie Doki?"] = {
            Artist = "The Stupendium",
            Credits = "The Stupendium // Charted by HuniLuxe"
        },
        ["The Fine Print"] = {
            Artist = "The Stupendium",
            Credits = "The Stupendium // Charted by HuniLuxe"
        },
        ["AD INFINITUM"] = {
            Artist = "The Stupendium",
            Credits = "The Stupendium // Charted by HuniLuxe"
        },
        ["Sakura Fubuki"] = {
            Artist = "Street",
            Credits = "Street // Charted by maris_a"
        },
        ["Dark Sheep"] = {
            Artist = "Chroma",
            Credits = "Chroma",
            Difficulties = {
                Everlasting = "+ // Charted by KadeDev",
                Insane = "+ // Charted by waxatak"
            }
        },
        ["sink to the deep sea world"] = {
            Artist = "Chroma",
            Credits = "Chroma // Charted by HuniLuxe"
        },
        ["We Luv Lama"] = {
            Artist = "DJ SHARPNEL",
            Credits = "DJ SHARPNEL // Charted by Rubignius"
        },
        ["BLUE ARMY"] = {
            Artist = "DJ SHARPNEL",
            Credits = "DJ SHARPNEL // Charted by Maji"
        },
        ["Over the Fullereneshift"] = {
            Artist = "DJ SHARPNEL",
            Credits = "DJ SHARPNEL // Charted by Maji"
        },
        ["You Touched The Kore, and Now You\'re Going to Die"] = {
            Artist = "DJ SHARPNEL ft. M-Project",
            Credits = "DJ SHARPNEL & M-Project // Charted by thebluefrawog"
        },
        ["Intersect Thunderbolt (Remix)"] = {
            Artist = "Saitama Saisyu Heiki",
            Credits = "Saitama Saisyu Heiki & Tennen-sozai",
            Difficulties = {
                Insane = "+ // Charted by benmuga",
                Exhausted = "+ // Charted by maris_a",
                Unfair = "+ // Charted by thebluefrawog"
            }
        },
        ["BPM=RT"] = {
            Artist = "t+pazolite",
            Credits = "t+pazolite // Charted by maris_a"
        },
        Dogbite = {
            Artist = "t+pazolite",
            Credits = "t+pazolite // Charted by maris_a"
        },
        ["Through the Fire and Flames"] = {
            Artist = "DragonForce",
            Credits = "DragonForce",
            Difficulties = {
                X_X = "+ // Charted by HuniLuxe",
                ["Exhausted (4K)"] = "+ // Charted by waxatak",
                ["Expert (4K)"] = "+ // Charted by The Hypno\'s Lullaby Team"
            }
        },
        ["Symphony of the Night"] = {
            Artist = "DragonForce",
            Credits = "DragonForce // Charted by Benmuga"
        },
        Isolation = {
            Artist = "NightHawk22",
            Credits = "NightHawk22",
            Difficulties = {
                Hard = "+ // Community Chart by BKetchup",
                FOCUS = "+ // Charted by 2ndEdition",
                LIMBO = "+ // Charted by thebluefrawog"
            }
        },
        ["Animation Warrior Theme"] = {
            Artist = "NightHawk22",
            Credits = "NightHawk22 // Charted by cqmbo"
        },
        ["RUN!"] = {
            Artist = "Sophus Alf Agerbæk-Larsen & Troels Jørgensen",
            Credits = "Ghost Ship Games, Sophus Alf Agerbæk-Larsen & Troels Jørgensen // Charted by comedy_individual"
        },
        ["Axes Out"] = {
            Artist = "Sophus Alf Agerbæk-Larsen & Troels Jørgensen",
            Credits = "Ghost Ship Games, Sophus Alf Agerbæk-Larsen & Troels Jørgensen // Charted by comedy_individual"
        },
        ["Megalo Strike Back"] = {
            Artist = "Toby Fox",
            Credits = "Toby Fox // Charted by RhysRJJ"
        },
        Screamroom = {
            Artist = "Xtrullor",
            Credits = "Xtrullor // Charted by maris_a"
        },
        Ena = {
            Artist = "Hinkik",
            Credits = "Hinkik // Charted by thebluefrawog"
        },
        Dimension = {
            Artist = "Creo",
            Credits = "Creo // Charted by benmuga"
        },
        ["Come Together Now"] = {
            Artist = "Teminite",
            Credits = "Teminite // Charted by RhysRJJ"
        },
        ArchangeL = {
            Artist = "Sydosys",
            Credits = "Sydosys // Charted by jian_awesome"
        },
        Endgame = {
            Artist = "Waterflame",
            Credits = "Waterflame // Charted by benmuga"
        },
        ["Ghost in the Machine"] = {
            Artist = "Shadrow",
            Credits = "Shadrow // Charted by RhysRJJ"
        },
        ["Never Be Alone"] = {
            Artist = "Shadrow",
            Credits = "Shadrow // Charted by Kappy"
        },
        ["Gangnam Style"] = {
            Artist = "PSY",
            Credits = "PSY // Charted by Twirl"
        },
        Gentleman = {
            Artist = "PSY",
            Credits = "PSY // Charted by thebluefrawog"
        },
        ["Fall \'N\' Roll"] = {
            Artist = "Jukio Kallio & Daniel Hagström",
            Credits = "Jukio Kallio, Daniel Hagström, Mediatronic & Epic Games // Charted by Aura"
        },
        ["TOO FAR"] = {
            Artist = "ChaoticCanineCulture",
            Credits = "CK9C // Charted by PlushtrapDev"
        },
        ["You Can\'t Escape Me"] = {
            Artist = "ChaoticCanineCulture",
            Credits = "CK9C // Charted by PlushtrapDev"
        },
        BIKE = {
            Artist = "TANGER",
            Credits = "TANGER",
            Difficulties = {
                Epileptic = "+ // Charted by 2ndEdition",
                Expert = "+ // Charted by Benmuga",
                Exhausted = "+ // Charted by Maji"
            }
        },
        Eltaw = {
            Artist = "Fl00t",
            Credits = "Fl00t // Charted by maris_a"
        },
        ["NONE OF THIS CONCERNS YOU"] = {
            Artist = "Tawaci",
            Credits = "Tawaci // Charted by maris_a"
        },
        ["Domain of Dust and Desolation"] = {
            Artist = "Satoshi Hori",
            Credits = "Satoshi Hori & Capcom Sound Team // Charted by Aura"
        }
    },
    Colors = {
        ["Justicia Dorada"] = ColorSequence.new(Color3.new(1, 0.333333, 0), Color3.new(1, 1, 0)),
        club2010 = ColorSequence.new(Color3.new(1, 0.333333, 0), Color3.new(1, 1, 0)),
        ["Wild West"] = Color3.new(1, 0, 0),
        ["What Goes Up"] = Color3.new(1, 0, 0),
        Summer = Color3.new(0.666667, 0.47451, 0.203922),
        Nomu = Color3.new(0.917647, 0.494118, 0.392157),
        ["NOOB KING"] = Color3.new(0.85098, 0, 0),
        ["TERRIBLE THINGS"] = ColorSequence.new(Color3.new(0.333333, 0.333333, 0), Color3.new(0.666667, 0, 1)),
        ["Burning Desires"] = Color3.new(1, 0.482353, 0.184314),
        ["Come Alive"] = Color3.new(1, 0.482353, 0.184314),
        ["RUSH E"] = ColorSequence.new(Color3.new(0.968627, 0.00392157, 0.00784314), Color3.new(0.996078, 0.945098, 0.0117647)),
        ["TWISTED GARDEN"] = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.new(1, 1, 0.498039)),
            ColorSequenceKeypoint.new(0.15, Color3.new(1, 1, 1)),
            ColorSequenceKeypoint.new(0.85, Color3.new(1, 1, 1)),
            ColorSequenceKeypoint.new(1, Color3.new(1, 0.333333, 0))
        }),
        Candyland = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.new(0.831373, 0.152941, 0)),
            ColorSequenceKeypoint.new(0.14, Color3.new(0.831373, 0.152941, 0)),
            ColorSequenceKeypoint.new(0.141, Color3.new(0.898039, 0.588235, 0.0431373)),
            ColorSequenceKeypoint.new(0.28, Color3.new(0.898039, 0.588235, 0.0431373)),
            ColorSequenceKeypoint.new(0.281, Color3.new(0.976471, 0.898039, 0.215686)),
            ColorSequenceKeypoint.new(0.42, Color3.new(0.976471, 0.898039, 0.215686)),
            ColorSequenceKeypoint.new(0.421, Color3.new(0.517647, 0.992157, 0.32549)),
            ColorSequenceKeypoint.new(0.56, Color3.new(0.517647, 0.992157, 0.32549)),
            ColorSequenceKeypoint.new(0.561, Color3.new(0.239216, 0.768627, 1)),
            ColorSequenceKeypoint.new(0.7, Color3.new(0.239216, 0.768627, 1)),
            ColorSequenceKeypoint.new(0.701, Color3.new(0.0823529, 0.14902, 0.713725)),
            ColorSequenceKeypoint.new(0.84, Color3.new(0.0823529, 0.14902, 0.713725)),
            ColorSequenceKeypoint.new(0.841, Color3.new(0.619608, 0.113725, 0.717647)),
            ColorSequenceKeypoint.new(1, Color3.new(0.619608, 0.113725, 0.717647))
        }),
        ["Pine Nut"] = Color3.new(0, 0.333333, 1),
        Shiawase = ColorSequence.new(Color3.new(0.14902, 0.517647, 1), Color3.new(1, 0.0392157, 0.694118)),
        ["Komodo Dragon (Sparky Mix)"] = Color3.new(0.666667, 0.647059, 0.372549),
        ["Schoolhouse Invasion"] = Color3.new(0.333333, 1, 0),
        Dyad = ColorSequence.new(Color3.new(1, 0.360784, 0.145098), Color3.new(0.513725, 0.666667, 0.0117647)),
        ["2MUCH2BEAR"] = Color3.new(0.65098, 0.65098, 0.65098),
        ["Red Zone"] = Color3.new(0.333333, 0, 0),
        ["Title Screen"] = Color3.new(0.756863, 0, 0),
        ["MONTAGEM XONADA (ImPaper Mix)"] = Color3.new(0.423529, 0.423529, 0.423529),
        Altale = Color3.new(1, 0.67451, 0.305882),
        ["BUTCHER VANITY"] = Color3.new(1, 1, 0),
        ["Water the Roses"] = Color3.new(1, 0.67451, 0.305882),
        ["far in the blue sky..."] = Color3.new(0.635294, 0.811765, 1),
        ["MEET.YOUR.TORMENTOR"] = Color3.new(1, 0, 0),
        ["SPIRIT KILLERS"] = Color3.new(0.333333, 1, 0),
        ["A SPECIAL TREE."] = Color3.new(0.333333, 0, 0),
        ["PRETTY STARS"] = ColorSequence.new(Color3.new(1, 1, 1), Color3.new(0, 0, 0)),
        ["Dark Woon"] = Color3.new(1, 1, 1),
        Ritual = Color3.new(0.588235, 0.588235, 0.588235),
        ["Dragon Hunt"] = Color3.new(1, 0.839216, 0.360784),
        ["You Belong To Me"] = Color3.new(1, 0, 0),
        ["Know Your Place"] = Color3.new(0.129412, 0.129412, 0.129412),
        ["PREPARE YOUR DEFENSEZ"] = Color3.new(0.666667, 0.333333, 0.498039),
        ["BANG BANG BANG"] = Color3.new(0.784314, 0.784314, 0.784314),
        ["月葬"] = Color3.new(0.317647, 0, 1),
        storm = Color3.new(0.117647, 0.117647, 0.117647),
        OVERTiME = Color3.new(0.666667, 0, 0),
        ["GOOD ENOUGH!"] = Color3.new(0.666667, 0.00392157, 0.235294),
        ["PAST MY PRIME TIME"] = ColorSequence.new(Color3.new(0.666667, 0.00392157, 0.235294), Color3.new(0.117647, 0.117647, 0.117647)),
        ANTIHUMAN = Color3.new(1, 0.333333, 0.498039),
        ["SLUGCAT PINBALL"] = Color3.new(0.321569, 0.87451, 1),
        INFAMOUS = Color3.new(0.419608, 0.137255, 0.498039),
        Fire = Color3.new(0.447059, 0.396078, 0.811765),
        ["Raining Tacos"] = Color3.new(1, 0.835294, 0.184314),
        ["crash and burn"] = Color3.new(0.2, 0.211765, 0.490196),
        Screamroom = Color3.new(1, 1, 1),
        ["Come Together Now"] = Color3.new(0.956863, 0.129412, 0.533333),
        ["Lemon Tree (Lemon Dance)"] = Color3.new(0.992157, 1, 0.478431),
        ["Castle Invaded"] = Color3.new(0.337255, 0.94902, 0.905882),
        ["Laser Mayhem (Slow)"] = Color3.new(0.337255, 0.94902, 0.905882),
        ["Last Wish"] = Color3.new(0.596078, 0.12549, 0.266667),
        ["song that plays when you encounter a caterpillar"] = Color3.new(0.498039, 1, 0.0313725),
        Challenger = Color3.new(0.729412, 0.247059, 0.12549),
        Dimension = Color3.new(0.611765, 0.611765, 0.721569),
        Ineffabilis = Color3.new(0.929412, 0.54902, 0.52549),
        ["Catch the Glory"] = Color3.new(0.92549, 0.788235, 0.317647),
        ["TO DUST THOU SHALT RETURN"] = Color3.new(0.92549, 0.27451, 0.831373),
        ["Red Lips (Mendus Remix)"] = Color3.new(0.572549, 0.00392157, 0.0313725),
        ["Moonlight (JustDazzel Cover)"] = Color3.new(0.92549, 0.592157, 0.682353),
        ["Dark Sheep"] = Color3.new(0.945098, 0.87451, 0.333333),
        ["sink to the deep sea world"] = Color3.new(0.333333, 0.333333, 1),
        ["Sakura Fubuki"] = Color3.new(0.866667, 0.607843, 0.760784),
        ["Brain Power"] = Color3.new(0.784314, 0.411765, 0.678431),
        ["Through the Fire and Flames"] = Color3.new(0.705882, 0.25098, 0.160784),
        ["Power of the Saber Blade"] = Color3.new(0.705882, 0.25098, 0.160784),
        ["Symphony of the Night"] = Color3.new(0.705882, 0.25098, 0.160784),
        Sustain = Color3.new(1, 0, 0),
        Isolation = Color3.new(0.00392157, 0.227451, 0.498039),
        ["Animation Warrior Theme"] = Color3.new(0.00392157, 0.227451, 0.498039),
        ["RUN!"] = Color3.new(0.164706, 0.498039, 0.313725),
        ["Axes Out"] = Color3.new(0.164706, 0.498039, 0.313725),
        ["Intersect Thunderbolt (Remix)"] = Color3.new(0.823529, 0.592157, 0.258824),
        Ena = Color3.new(0.184314, 0.278431, 0.631373),
        ["Warp Zone"] = ColorSequence.new(Color3.new(1, 0.203922, 0.203922), Color3.new(0.333333, 0.666667, 1)),
        ArchangeL = Color3.new(0.929412, 0.929412, 0.929412),
        Endgame = Color3.new(0.0117647, 0.72549, 0.878431),
        ["Electroman Adventures"] = Color3.new(0.0117647, 0.72549, 0.878431),
        ["Ghost in the Machine"] = Color3.new(0.333333, 0.333333, 0.498039),
        ["Never Be Alone"] = Color3.new(1, 0.835294, 0.00784314),
        ["Gangnam Style"] = Color3.new(0.25098, 0.713725, 1),
        Gentleman = Color3.new(0.25098, 0.713725, 1),
        ["The Ultimate Showdown of Ultimate Destiny"] = Color3.new(1, 1, 0),
        ["Two Trucks"] = Color3.new(1, 1, 0),
        ["Pizza Heroes"] = Color3.new(1, 1, 0),
        ["TOO FAR"] = Color3.new(0.745098, 0.188235, 0.215686),
        ["You Can\'t Escape Me"] = Color3.new(0.745098, 0.188235, 0.215686),
        ["Fall \'N\' Roll"] = Color3.new(1, 0.333333, 0.498039),
        ["BLUE ARMY"] = Color3.new(0.0431373, 0.345098, 0.54902),
        ["Over the Fullereneshift"] = Color3.new(0.984314, 0.576471, 0.733333),
        ["You Touched The Kore, and Now You\'re Going to Die"] = Color3.new(0, 0.223529, 0.584314),
        ["We Luv Lama"] = Color3.new(0.984314, 0.576471, 0.733333),
        BIKE = Color3.new(1, 0.364706, 0.113725),
        ["in my room"] = Color3.new(0.709804, 0.709804, 0.709804),
        ["Long Live The New Fresh (Live)"] = Color3.new(1, 0, 0.498039),
        ["Geometrical Dominator"] = Color3.new(0.431373, 0.92549, 0.0705882),
        Daydreamer = Color3.new(0, 0.333333, 1),
        Uncertain = Color3.new(0.282353, 0.290196, 0.290196),
        ["M-A"] = Color3.new(0.666667, 0, 0),
        Cascade = Color3.new(1, 0.584314, 0.243137),
        ["BPM=RT"] = Color3.new(0.65098, 0.121569, 0.121569),
        Dogbite = Color3.new(1, 1, 1),
        Eltaw = Color3.new(0.65098, 0.545098, 0.419608),
        ["NONE OF THIS CONCERNS YOU"] = Color3.new(0.462745, 0.462745, 0.462745),
        ["Fly Me to The Moon (∞ Climax Mix)"] = ColorSequence.new(Color3.new(0, 0, 0), Color3.new(0.666667, 0, 0)),
        ["Domain of Dust and Desolation"] = Color3.new(0.847059, 0.698039, 0.4),
        ["The Most Fashionable Faction"] = Color3.new(0.980392, 0.431373, 0.290196),
        ["Why Did I Say Okie Doki?"] = Color3.new(1, 0.666667, 1),
        ["The Fine Print"] = Color3.new(0.0431373, 0.333333, 0.211765),
        ["AD INFINITUM"] = Color3.new(1, 1, 1),
        ["Sweet Release of Death"] = Color3.new(1, 0.368627, 0.764706),
        ["change my mind"] = Color3.new(0.105882, 0.105882, 0.105882),
        ["I wanna be a girl"] = Color3.new(1, 0.768627, 0.996078),
        ["Yume no Mata Yume"] = Color3.new(0.345098, 0.682353, 1),
        ["Non-breath oblige"] = Color3.new(0.776471, 0.388235, 1),
        ["[Lycoris]"] = Color3.new(0.32549, 0.32549, 0.32549),
        ["The Big Black"] = Color3.new(1, 0.0784314, 0.0941176),
        Terminal = Color3.new(1, 0.0784314, 0.0941176),
        ["Rainbow Tylenol"] = Color3.new(0.333333, 1, 0.498039),
        ["around and around"] = Color3.new(0.313725, 0.313725, 0.313725),
        hanshin = Color3.new(0, 0, 0),
        ["quietly, quietly die"] = Color3.new(0.0784314, 0.262745, 0.670588),
        ["Game On, Beats High"] = Color3.new(0.4, 0.239216, 0.72549),
        Titanium = Color3.new(1, 1, 1),
        Partition = Color3.new(0.0627451, 0.0627451, 0.0627451),
        Kratos = Color3.new(1, 0.776471, 0.0980392),
        ["Megalo Strike Back"] = Color3.new(0.760784, 0.760784, 0.760784),
        ["4drift"] = Color3.new(0.760784, 0.760784, 0.760784),
        detach = Color3.new(0.760784, 0.760784, 0.760784),
        silly = Color3.new(0.760784, 0.760784, 0.760784)
    },
    SongIcons = {
        storm = "rbxassetid://122102703809096",
        OVERTiME = "rbxassetid://122102703809096",
        ["GOOD ENOUGH!"] = "rbxassetid://122102703809096",
        ["PAST MY PRIME TIME"] = "rbxassetid://122102703809096",
        ["Know Your Place"] = "rbxassetid://72557977855699",
        ["Come Alive"] = "rbxassetid://74179156608508",
        ["Burning Desires"] = "rbxassetid://74179156608508",
        ["Dark Woon"] = "rbxassetid://132021113171680",
        Candyland = "rbxassetid://83549844042057",
        ["2MUCH2BEAR"] = "rbxassetid://140362002539081",
        Titanium = "rbxassetid://136205298450166",
        ["BANG BANG BANG"] = "rbxassetid://78301325382656",
        ["change my mind"] = "rbxassetid://97913455444684",
        ANTIHUMAN = "rbxassetid://113437346229109",
        ["SLUGCAT PINBALL"] = "rbxassetid://113437346229109",
        INFAMOUS = "rbxassetid://113437346229109",
        Fire = "rbxassetid://15432533585",
        Shiawase = "rbxassetid://15432533585",
        ["Komodo Dragon (Sparky Mix)"] = "rbxassetid://103334949590683",
        ["Schoolhouse Invasion"] = "rbxassetid://103334949590683",
        Dyad = "rbxassetid://82215262902757",
        ["Title Screen"] = "rbxassetid://110388068824781",
        ["The Ultimate Showdown of Ultimate Destiny"] = "rbxassetid://18796398554",
        ["Two Trucks"] = "rbxassetid://18796398554",
        ["Pizza Heroes"] = "rbxassetid://18796398554",
        ["Fly Me to The Moon (∞ Climax Mix)"] = "rbxassetid://19006600438",
        Sustain = "rbxassetid://18407339435",
        ["Castle Invaded"] = "rbxassetid://18407339741",
        ["Laser Mayhem (Slow)"] = "rbxassetid://18407339741",
        ["Last Wish"] = "rbxassetid://18407339982",
        Challenger = "rbxassetid://18407340163",
        Dimension = "rbxassetid://18407340163",
        ["Dark Sheep"] = "rbxassetid://18407340626",
        ["sink to the deep sea world"] = "rbxassetid://18407340626",
        ["tiny tales continue"] = "rbxassetid://18407340626",
        ["月葬"] = "rbxassetid://18407340626",
        ["Geometrical Dominator"] = "rbxassetid://71061629200794",
        ["PREPARE YOUR DEFENSEZ"] = "rbxassetid://130574024722267",
        ["Through the Fire and Flames"] = "rbxassetid://18407341048",
        ["Symphony of the Night"] = "rbxassetid://18407341048",
        ["Power of the Saber Blade"] = "rbxassetid://18407341048",
        Screamroom = "rbxassetid://18407341208",
        Isolation = "rbxassetid://18407341661",
        Orbit = "rbxassetid://18407341661",
        Ritual = "rbxassetid://134948796274350",
        ["Dragon Hunt"] = "rbxassetid://72962406851992",
        Endgame = "rbxassetid://18407342601",
        ["Electroman Adventures"] = "rbxassetid://18407342601",
        ["Fall \'N\' Roll"] = "rbxassetid://18407342940",
        ["Domain of Dust and Desolation"] = "rbxassetid://18407343859",
        ["Sweet Release of Death"] = "rbxassetid://18594087703",
        ["RUN!"] = "rbxassetid://15906387866",
        ["Axes Out"] = "rbxassetid://15906387866",
        ["Ghost in the Machine"] = "rbxassetid://16493667594",
        ["Never Be Alone"] = "rbxassetid://16493667594",
        ["Gangnam Style"] = "rbxassetid://16493668636",
        Gentleman = "rbxassetid://16493668636",
        ["TOO FAR"] = "rbxassetid://16811743938",
        ["You Can\'t Escape Me"] = "rbxassetid://16811743938",
        ["The Most Fashionable Faction"] = "rbxassetid://18219321771",
        ["Why Did I Say Okie Doki?"] = "rbxassetid://18219321771",
        ["The Fine Print"] = "rbxassetid://18219321771",
        ["AD INFINITUM"] = "rbxassetid://18219321771",
        ["Intersect Thunderbolt (Remix)"] = "rbxassetid://18594295853",
        ["SPIRIT KILLERS"] = "rbxassetid://136368361377831",
        ["MEET.YOUR.TORMENTOR"] = "rbxassetid://106724066457916",
        ["PRETTY STARS"] = "rbxassetid://113550660155794",
        ["A SPECIAL TREE."] = "rbxassetid://108363215066099"
    },
    CustomIcons = {
        ["Sweet Release of Death"] = {
            LeftIcon = "Pizzelle",
            RightIcon = "The Noise",
            IconPacks = {
                R = "Pizza Tower"
            }
        }
    }
};