-- Decompiled with Potassium's decompiler.

return {
    Credits = "Banbuds, Rozebud, KadeDev, Cval, YingYang48, JADS, MORØ Nighteye, Tom Fulp, Krinkles, Tsuraran & DeveloVoosh GWeb",
    Icon = "rbxassetid://14759705595",
    IconPack = "Tricky",
    Color = Color3.new(0, 0.333333, 0),
    Weeks = { {
            Name = "CLOWN",
            Songs = { "Improbable Outset", "Madness", "HELLCLOWN" }
        }, {
            Name = "Freeplay",
            Songs = { "Expurgation", "Violence", "COLOSSUS" }
        }, {
            Name = "Remasters",
            Songs = { "Madness (2024 Remastered)" }
        } },
    Colors = {
        HELLCLOWN = Color3.new(1, 0, 0),
        COLOSSUS = Color3.new(1, 1, 1),
        Expurgation = Color3.new(0.780392, 0, 0)
    },
    SongIcons = {
        ["Improbable Outset"] = "rbxassetid://125874607013090",
        HELLCLOWN = "rbxassetid://15173438419",
        COLOSSUS = "rbxassetid://15173438419",
        Expurgation = "rbxassetid://15173440147"
    },
    ExtraCredits = {
        Expurgation = {
            Credits = "+ // Background by Huso",
            Difficulties = {
                ["Unfair (6K)"] = "+ \nCharted by TRFerret",
                ["Unfair (ALT)"] = "+ \nCharted by maybematt_there"
            }
        },
        HELLCLOWN = {
            Credits = "+ // Background by Tricky"
        },
        ["Improbable Outset"] = {
            Credits = "+ // Background by Tricky",
            Difficulties = {
                ["Hard (ALT)"] = "+ // Charted by Tiel",
                ["Hard (ALT 2)"] = "+ // Charted by maybematt_there"
            }
        },
        Madness = {
            Credits = "+ // Background by Tricky",
            Difficulties = {
                ["Hard (6K)"] = "+ \nCharted by TRFerret",
                ["Hard (ALT)"] = "+ \nCharted by maybematt_there"
            }
        },
        ["Madness (2024 Remastered)"] = {
            Credits = "+ // Background by Tricky",
            Difficulties = {
                Hard = "+ \nCharted by RhysRJJ"
            }
        },
        Violence = {
            Credits = "+ // Background by Tricky",
            Difficulties = {
                ["Hard (ALT)"] = "+ \nCharted by Twirl"
            }
        },
        COLOSSUS = {
            Credits = "+ // Background by Tricky",
            Difficulties = {
                Unfair = "+ \nCharted by RhysRJJ"
            }
        }
    },
    CustomIcons = {
        ["Improbable Outset"] = {
            LeftIcon = "Tricky (Masked)",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        Violence = {
            LeftIcon = "Tricky (Masked)",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        Madness = {
            LeftIcon = "Tricky",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        ["Madness (2024 Remastered)"] = {
            LeftIcon = "Tricky",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        HELLCLOWN = {
            LeftIcon = "Demon Tricky",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        COLOSSUS = {
            LeftIcon = "Demon Tricky",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        },
        Expurgation = {
            LeftIcon = "Tricky (EX)",
            RightIcon = "BF",
            IconPacks = {
                R = "Friday Night Funkin\'"
            }
        }
    }
};