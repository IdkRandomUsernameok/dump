-- Decompiled with Potassium's decompiler.

return {
    onNote = function(p1) -- Line: 2, Name: onNote
        if p1.rawData[4] == "Hurt Note" then
            p1.texture = "TrickyDeath";
            p1.textureFallback = "LeatherHurtNotes";
            p1.hitCausesMiss = true;
            p1.ignoreNote = true;
            p1.shouldBeHitted = false;
            p1.hitbox = 0.5;
            p1.killOnHit = true;
            p1.hitSound = "rbxassetid://15986776817";
        end;
    end
};