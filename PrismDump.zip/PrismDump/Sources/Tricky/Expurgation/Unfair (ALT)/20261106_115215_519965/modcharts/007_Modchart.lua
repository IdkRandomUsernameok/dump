-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
require(ReplicatedStorage.Modules.Types);
local u1 = nil;
local u2 = nil;
local _ = ReplicatedStorage.Modules;
local u3 = false;
local Sprite = require(ReplicatedStorage.Modules.Main.Sprite);
local CacheService = require(ReplicatedStorage.Modules.Main.CacheService);
local VarTweener = require(ReplicatedStorage.Modules.Main.VarTweener);
local u4 = {};

function doStopSign(p5: number, p6: boolean, p7: boolean)
    -- upvalues: u2 (ref), Sprite (copy), u4 (copy)
    local v8 = p5 or 0;

    if p6 == nil or not p6 then
        p6 = false;
    end;

    if p7 == nil or not p7 then
        p7 = false;
    end;

    local Setting = u2.getSetting(u2.Side, "Downscroll");
    local Setting2 = u2.getSetting(u2.Side, "Middlescroll");
    local u9 = nil;
    local v10 = nil;

    if v8 == 0 then
        u9 = Sprite.new(script.preload_multiImage.StopSign1:Clone(), nil, true);
        u9:loadGraphic(script.preload_multiImage.StopSign1.XML, nil, 2.884765625);
        u9.useAngleAnchor = true;
        u9.angleAnchor = u9.Obj.AnchorPoint;
        u9.scale.set(0.6, 0.6);
        local v11 = {};

        for i = 0, 50 do
            table.insert(v11, i);
            local _ = i;
        end;

        u9:addByIndices("sign", "Signature Stop Sign 1", v11, nil, 24, p7);
        u9.angle = -90;
        v10 = UDim2.fromScale(1.1, 0.5);
    elseif v8 == 2 then
        u9 = Sprite.new(script.preload_multiImage.StopSign4:Clone(), nil, true);
        u9:loadGraphic(script.preload_multiImage.StopSign4.XML, nil, 2.44140625);
        u9.useAngleAnchor = true;
        u9.angleAnchor = u9.Obj.AnchorPoint;
        u9.scale.set(0.6, 0.6);
        local v12 = {};

        for i = 0, 233 do
            table.insert(v12, i);
            local _ = i;
        end;

        u9:addByIndices("sign", "Signature Stop Sign 4", v12, nil, 24, p7);
        u9.angle = -90;
        v10 = UDim2.fromScale(1.1, 0.5);
    elseif v8 == 3 then
        u9 = Sprite.new(script.preload_multiImage.StopSign3:Clone(), nil, true);
        u9:loadGraphic(script.preload_multiImage.StopSign3.XML, nil, 1.5576171875);
        u9.useAngleAnchor = true;
        u9.angleAnchor = u9.Obj.AnchorPoint;
        u9.scale.set(0.6, 0.6);
        local v13 = {};

        for i = 0, 76 do
            table.insert(v13, i);
            local _ = i;
        end;

        u9:addByIndices("sign", "Signature Stop Sign 3", v13, nil, 24, p7);
        u9.angle = -90;
        v10 = UDim2.fromScale(1.045, (Setting == nil or not Setting) and 0.075 or 0.925);
    end;

    if not u9 then
        return warn("Sign", v8, "doesn\'t exist!");
    end;

    table.insert(u4, u9);
    u9.AnimationEnded:Connect(function() -- Line: 119
        -- upvalues: u4 (ref), u9 (ref)
        table.remove(u4, table.find(u4, u9));
        u9:Destroy();
    end);
    u9.parent = u2.Game;
    u9.Position = v10;
    u9.zindex = 9999998;
    u9.flipX = p6;

    if Setting then
        u9.flipX = not u9.flipX;
    end;

    if u2.Side == "L" and not Setting2 then
        u9.flipX = not u9.flipX;
        u9.angle = 90;
        u9.Position = UDim2.fromScale(1 - v10.X.Scale + 0.1, v10.Y.Scale);
    end;

    if Setting2 then
        if v8 == 0 then
            local v14 = Setting and (u9.flipX and 0.75 or 0.25) or (u9.flipX and 0.25 or 0.75);
            local v15 = Setting and UDim2.fromScale(v14, -0.125) or UDim2.fromScale(v14, 1.125);
            u9.angle = Setting and -180 or 0;
            u9.Position = v15;
        elseif v8 == 2 then
            local v16 = u9.flipX and 0.55 or 0.45;
            local v17 = Setting and UDim2.fromScale(v16, 1.1) or UDim2.fromScale(v16, -0.1);
            u9.angle = Setting and 0 or -180;
            u9.Position = v17;
        elseif v8 == 3 then
            local v18 = Setting and (u9.flipX and -100 or 100) or (u9.flipX and 100 or -100);
            local v19 = u9.flipX and 0.25 or 0.75;
            local v20 = Setting and UDim2.fromScale(v19, 1.01) or UDim2.fromScale(v19, -0.01);
            u9.angle = v18;
            u9.Position = v20;
            u9.flipY = Setting;
        end;
    end;

    u9:PlayAnimation("sign");
end;

local u21 = nil;
local u22 = nil;
local u23 = false;
local u24 = false;
local u25 = nil;

function doGremlin(p26: number, p27: number, u28: boolean)
    -- upvalues: u2 (ref), u23 (ref), u24 (ref), u21 (ref), u22 (ref), u1 (ref), Sprite (copy), u4 (copy), VarTweener (copy)
    local u29 = p27 and p27 / u2.playbackRate or 1 / u2.playbackRate;
    u2.setProperty("healthStats.gainMult", 0);
    u23 = false;
    u24 = true;
    local u30 = false;
    local healthStats = u2.healthStats;
    local maxHealth = healthStats.maxHealth;
    local currentHealth = healthStats.currentHealth;
    local u31 = currentHealth * (p26 / 100);
    u2.playSound("rbxassetid://129114189640886", 1);
    u21 = u2.HUD.HPBar.AbsolutePosition;
    u22 = u2.HUD.HPBar.AbsoluteSize;
    local v32 = u2.Side == "R" and (currentHealth - maxHealth) * -1 / maxHealth or currentHealth / maxHealth;
    local v33 = u2.Side == "R" and (u31 - maxHealth) * -1 / maxHealth or u31 / maxHealth;
    local v34 = 0.109375 * u1.ViewportSize.X;
    local u35 = (u21.X + (u2.Side == "R" and v34 and v34 or -v34) + math.lerp(0, u22.X, v32)) / u1.ViewportSize.X;
    local u36 = (u21.X + math.lerp(0, u22.X, v32)) / u1.ViewportSize.X;
    local u37 = (u21.X + math.lerp(0, u22.X, v33)) / u1.ViewportSize.X;
    local u38 = Sprite.new(script.preload_multiImage.HP_GREMLIN:Clone(), nil, true, true);
    u38:loadGraphic(script.preload_multiImage.HP_GREMLIN.XML, nil, 1.787109375);
    u38.scale.set(0.54328125, 0.54328125);
    local v39 = {};

    for i = 2, 24 do
        table.insert(v39, i);
        local _ = i;
    end;

    u38:addByIndices("come", "HP Gremlin ANIMATION", { 0, 1 }, nil, 24, false);
    u38:addByIndices("grab", "HP Gremlin ANIMATION", v39, nil, 24, false);
    u38:addByIndices("hold", "HP Gremlin ANIMATION", { 25, 26, 27, 28 }, nil, 24, true);
    u38:addByIndices("release", "HP Gremlin ANIMATION", { 29, 30, 31, 32, 33 }, nil, 24, false);
    table.insert(u4, u38);
    u38.AnimationEnded:Connect(function(p40) -- Line: 235
        -- upvalues: u38 (ref), VarTweener (ref), u35 (copy), u36 (copy), u2 (ref), u37 (copy), u29 (ref), u23 (ref), u30 (ref), u28 (copy), currentHealth (copy), u31 (copy), u4 (ref), u24 (ref)
        if p40 == "come" then
            u38:PlayAnimation("grab", true);
            local v42 = VarTweener:CreateValueTween(u35, u36, TweenInfo.new(1 / u2.playbackRate, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), function(p41) -- Line: 239
                -- upvalues: u38 (ref)
                u38.Position = UDim2.fromScale(p41, u38.Position.Y.Scale);
            end);
            v42.Completed:Connect(function() -- Line: 242
                -- upvalues: u38 (ref), VarTweener (ref), u36 (ref), u37 (ref), u29 (ref), u23 (ref), u30 (ref), u28 (ref), u2 (ref), currentHealth (ref), u31 (ref)
                u38:Play("hold", true);
                local u43 = nil;
                u43 = VarTweener:CreateValueTween(u36, u37, TweenInfo.new(u29, Enum.EasingStyle.Linear, Enum.EasingDirection.In), function(p44) -- Line: 245
                    -- upvalues: u38 (ref), u23 (ref), u30 (ref), u28 (ref), u43 (ref), u2 (ref), currentHealth (ref), u31 (ref)
                    u38.Position = UDim2.fromScale(p44, u38.Position.Y.Scale);

                    if not u23 or (u30 or u28) then
                        if not u23 or u28 then
                            u2.setHealth((math.lerp(currentHealth, u31, u43:GetProgress())));
                        end;

                        return;
                    end;

                    u43:Cancel();
                    u30 = true;
                    u38:PlayAnimation("release", true);
                end);
                u43.Completed:Connect(function() -- Line: 255
                    -- upvalues: u23 (ref), u38 (ref)
                    if not u23 then
                        u38:PlayAnimation("release", true);
                    end;
                end);
                u43:Play();
            end);
            v42:Play();
        end;

        if p40 == "release" then
            u2.setProperty("healthStats.gainMult", 1);
            table.remove(u4, table.find(u4, u38));
            u38:Destroy();
            u24 = false;
        end;
    end);
    u38.parent = u2.HUD;
    u38.flipY = u2.Settings.Downscroll or false;
    u38.flipX = u2.Side == "L";
    u38.zindex = 9999999;
    u38.AnchorPoint = Vector2.new(u2.Side == "L" and 0.9 or 0.1, 0.5);
    u38.Position = UDim2.fromScale(u35, u2.Settings.Downscroll and 0 or 1);
    u38.visible = u2.getSetting(nil, "HealthBar");
    table.insert(u4, u38);
    u38:PlayAnimation("come", true);
    u2.playSound(script.preload.GremlinWoosh);
end;

return {
    onCreate = function(p45) -- Line: 289, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), CacheService (copy), Sprite (copy), u3 (ref)
        u1 = game:GetService("Workspace").CurrentCamera;
        u2 = p45;
        u2.setProperty("healthStats.forceHealthDrain", true);
        u2.setProperty("healthStats.lossMult", 0);

        for _, child in script.preload:GetChildren() do
            CacheService.cacheAsset(child);
        end;

        for _, child in script.preload_multiImage:GetChildren() do
            local XML = child:FindFirstChild("XML");
            local v46 = XML and XML:IsA("ModuleScript") and XML.Name == "XML";

            if XML and v46 then
                for _, v in Sprite:GetSpriteImages(XML) do
                    CacheService.cacheImage(v);
                end;
            end;
        end;

        for _, v in u2.getCharacters("L") do
            if v.currentAnim == "EX Tricky" then
                u3 = true;
                u2.cancelSongStart();
            end;
        end;

        if u3 then
            u2.HUDApi:SetVisibility(false);
            u2.Game.Visible = false;
        end;
    end,

    onLoad = function() -- Line: 327, Name: onLoad
        -- upvalues: u3 (ref), u2 (ref)
        if not u3 then
            return;
        end;

        for _, v in u2.getCharacters("L") do
            v:Play("ExpurgCutscene");
        end;

        u2.setProperty("cameraTargetId", 0);
        u2.playSound("rbxassetid://121685057234499", 1);
        u2.delay(1, function() -- Line: 336
            -- upvalues: u2 (ref)
            u2.playSound("rbxassetid://130179077570503", 1);
        end);
        u2.delay(1.5, function() -- Line: 340
            -- upvalues: u2 (ref)
            u2.Game.Visible = true;
            u2.HUDApi:SetVisibility(true);
            u2.beginCountdown();
        end);
    end,

    onCountdown = function(p47: any, p48: userdata) -- Line: 348, Name: onCountdown
        -- upvalues: u25 (ref), u2 (ref), u24 (ref)
        if p47 == 3 then
            u25 = task.spawn(function() -- Line: 350
                -- upvalues: u2 (ref), u24 (ref)
                while true do
                    repeat
                        task.wait(25);
                    until u2.Conductor.Step < 2400 and not u24;

                    local healthStats = u2.healthStats;

                    if healthStats.currentHealth / healthStats.maxHealth > 0.75 then
                        doGremlin(40, 3);
                    end;
                end;
            end);
        end;
    end,

    onPlayerNoteHit = function(p49) -- Line: 371, Name: onPlayerNoteHit
        -- upvalues: u24 (ref), u23 (ref)
        if p49.texture == "TrickyDeath" and u24 then
            u23 = true;
        end;
    end,

    onNoteMiss = function(p50) -- Line: 377, Name: onNoteMiss
        -- upvalues: u24 (ref), u23 (ref)
        if u24 then
            u23 = true;
        end;
    end,

    clearUp = function() -- Line: 383, Name: clearUp
        -- upvalues: u4 (copy), u25 (ref)
        for _, v in u4 do
            if v ~= nil then
                v:Destroy();
            end;
        end;

        pcall(function() -- Line: 390
            -- upvalues: u25 (ref)
            task.cancel(u25);
        end);
    end,

    onBeatHit = function(p51: number) -- Line: 395, Name: onBeatHit
        -- upvalues: u2 (ref)
        if p51 == 530 then
            u2.setProperty("cameraTargetId", 0);

            return;
        end;

        if p51 == 532 then
            for _, v in u2.getCharacters("L") do
                v:Play("HAAAAAANK");
            end;

            return;
        end;

        if p51 == 536 then
            for _, v in u2.getCharacters("L") do
                v:Play("Idle");
            end;
        end;
    end,

    onStepHit = function(p52: number) -- Line: 409, Name: onStepHit
        if p52 == 384 then
            doStopSign(0);
        end;

        if p52 == 511 then
            doStopSign(2);
            doStopSign(0);
        end;

        if p52 == 610 then
            doStopSign(3);
        end;

        if p52 == 720 then
            doStopSign(2);
        end;

        if p52 == 991 then
            doStopSign(3);
        end;

        if p52 == 1184 then
            doStopSign(2);
        end;

        if p52 == 1200 then
            doStopSign(0);
        end;

        if p52 == 1218 then
            doStopSign(0);
        end;

        if p52 == 1235 then
            doStopSign(0, true);
        end;

        if p52 == 1328 then
            doStopSign(0, true);
            doStopSign(2);
        end;

        if p52 == 1439 then
            doStopSign(3, true);
        end;

        if p52 == 1567 then
            doStopSign(0);
        end;

        if p52 == 1584 then
            doStopSign(0, true);
        end;

        if p52 == 1600 then
            doStopSign(2);
        end;

        if p52 == 1706 then
            doStopSign(3);
        end;

        if p52 == 1917 then
            doStopSign(0);
        end;

        if p52 == 1923 then
            doStopSign(0, true);
        end;

        if p52 == 1927 then
            doStopSign(0);
        end;

        if p52 == 1932 then
            doStopSign(0, true);
        end;

        if p52 == 2032 then
            doStopSign(2);
            doStopSign(0);
        end;

        if p52 == 2036 then
            doStopSign(0, true);
        end;

        if p52 == 2162 then
            doStopSign(2);
            doStopSign(3);
        end;

        if p52 == 2193 then
            doStopSign(0);
        end;

        if p52 == 2202 then
            doStopSign(0, true);
        end;

        if p52 == 2239 then
            doStopSign(2, true);
        end;

        if p52 == 2258 then
            doStopSign(0, true);
        end;

        if p52 == 2304 then
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2326 then
            doStopSign(0, true);
        end;

        if p52 == 2336 then
            doStopSign(3);
        end;

        if p52 == 2447 then
            doStopSign(2);
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2480 then
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2512 then
            doStopSign(2);
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2544 then
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2575 then
            doStopSign(2);
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2608 then
            doStopSign(0, true);
            doStopSign(0);
        end;

        if p52 == 2604 then
            doStopSign(0, true);
        end;

        if p52 == 2655 then
            doGremlin(20, 13, true);
        end;
    end
};