-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
require(ReplicatedStorage.Modules.Types);
local Sprite = require(ReplicatedStorage.Modules.Main.Sprite);
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;

local function randomBool(p5: number) -- Line: 15
    if p5 > 0 then
        return math.random(1, 100) >= ((p5 > 100 and 100 or p5) - 100) * -1;
    end;
end;

local u6 = {
    Madness = 20,
    HELLCLOWN = 45,
    Expurgation = 60
};
local u7 = { "SUFFER", "INCORRECT", "INCOMPLETE", "INSUFFICIENT", "INVALID", "CORRECTION", "MISTAKE", "REDUCE", "ERROR", "ADJUSTING", "IMPROBABLE", "IMPLAUSIBLE", "MISJUDGED" };
local u8 = { "YOU AREN\'T HANK", "WHERE IS HANK", "HANK???", "WHO ARE YOU", "WHERE AM I", "THIS ISN\'T RIGHT", "MIDGET", "SYSTEM UNRESPONSIVE", "WHY CAN\'T I KILL?????" };
local u9 = { "TERRIBLE", "WASTE", "MISS CALCULTED", "PREDICTED", "FAILURE", "DISGUSTING", "ABHORRENT", "FORESEEN", "CONTEMPTIBLE", "PROGNOSTICATE", "DISPICABLE", "REPREHENSIBLE" };
local u10 = nil;
local u11 = nil;
local u12 = nil;
local u13 = false;
local u14 = true;
local u15 = nil;
local Vector2_new_ret = Vector2.new();

function createSpookyText(p16: string, p17: number, p18: number)
    -- upvalues: u12 (ref), u2 (ref), u13 (ref), u10 (ref), u11 (ref), Vector2_new_ret (ref)
    u12 = u2.Conductor.Step;
    u13 = true;

    if u2.Settings.CameraFlash then
        u10.alpha = 0.5;
    end;

    u2.playSound(script.clown.staticSound);
    u11.Text = p16;
    local v19 = math.random(40, 120) / 1280 * (math.random(1, 2) == 2 and -1 or 1);
    local v20 = math.random(20, 100) / 720;
    local v21 = math.random(1, 2) == 2 and 1 or -1;
    Vector2_new_ret = Vector2.new(v19, v20 * v21);
    u11.Visible = true;
end;

return {
    onCreate = function(p22) -- Line: 101, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), u3 (ref), u4 (ref), u14 (ref), u15 (ref), u8 (copy), u7 (copy), u10 (ref), Sprite (copy), u11 (ref)
        u1 = workspace.CurrentCamera;
        u2 = p22;
        u3 = u2.getCharacters("L");
        u4 = u2.songData.SongFile.Name;
        u14 = true;
        u15 = u4 == "Expurgation" and u8 or u7;
        u10 = Sprite.new(script.clown.TrickyStatic:Clone(), nil, true);
        u10:AddSparrowXml(script.clown.TrickyStatic.XML, "static", "static", 24, true);
        u10.parent = u2.Underlay;
        local v23 = ({
            ["!DEFAULT"] = 8.3,
            HELLCLOWN = 12
        })[u4] or 8.3;
        u10.scale.set(v23, v23);
        u10.Position = UDim2.fromScale(0.5, 0.5);
        u10.alpha = u4 == "Expurgation" and 0.1 or 0;
        u10:PlayAnimation("static", true);
        u11 = script.spookyText:Clone();
        u11.Parent = u2.Underlay;

        if u4 == "HELLCLOWN" then
            local Size = u11.Size;
            u11.Size = UDim2.new(Size.X.Scale * 1.5625, Size.X.Offset * 1.5625, Size.Y.Scale * 1.5625, Size.Y.Offset * 1.5625);
        end;
    end,

    onPlayerNoteHit = function(p24, p25) -- Line: 140, Name: onPlayerNoteHit
        -- upvalues: u13 (ref), u6 (copy), u4 (ref), u15 (ref)
        if p24.side == "L" and not (u13 or p24.isSustain) then
            local v26 = u6[u4] or 1;
            local v27;

            if v26 <= 0 then
                v27 = nil;
            else
                v27 = math.random(1, 100) >= ((v26 > 100 and 100 or v26) - 100) * -1;
            end;

            if v27 then
                createSpookyText(u15[math.random(1, #u15)]);
            end;
        end;
    end,

    onOpponentNoteHit = function(p28) -- Line: 148, Name: onOpponentNoteHit
        -- upvalues: u13 (ref), u6 (copy), u4 (ref), u15 (ref)
        if p28.side == "L" and not (u13 or p28.isSustain) then
            local v29 = u6[u4] or 1;
            local v30;

            if v29 <= 0 then
                v30 = nil;
            else
                v30 = math.random(1, 100) >= ((v29 > 100 and 100 or v29) - 100) * -1;
            end;

            if v30 then
                createSpookyText(u15[math.random(1, #u15)]);
            end;
        end;
    end,

    onNoteMiss = function(p31) -- Line: 156, Name: onNoteMiss
        -- upvalues: u13 (ref), u4 (ref), u9 (copy)
        if not u13 then
            local v32 = u4 == "Madness" and 10 or 4;
            local v33;

            if v32 <= 0 then
                v33 = nil;
            else
                v33 = math.random(1, 100) >= ((v32 > 100 and 100 or v32) - 100) * -1;
            end;

            if v33 then
                createSpookyText(u9[math.random(1, #u9)]);
            end;
        end;
    end,

    onStepHit = function(p34: number) -- Line: 165, Name: onStepHit
        -- upvalues: u13 (ref), u12 (ref), u14 (ref), u11 (ref), u10 (ref), u4 (ref)
        if u13 and u12 + 3 < p34 then
            if u14 then
                u13 = false;
                u11.Visible = false;
            end;

            u10.alpha = u4 == "Expurgation" and 0.1 or 0;
        end;
    end,

    onUpdate = function(p35: number) -- Line: 179, Name: onUpdate
        -- upvalues: u1 (ref), u3 (ref), u13 (ref), u11 (ref), Vector2_new_ret (ref), u10 (ref), u2 (ref)
        local v36, v37 = u1:WorldToScreenPoint(u3[0] and u3[0].currentPos and u3[0].currentPos.Position);

        if v37 or not u13 then
            if u13 and not u11.Visible then
                u11.Visible = true;
            end;
        else
            u11.Visible = false;
        end;

        if u11.Visible and v36 then
            u11.Position = UDim2.new(Vector2_new_ret.X, v36.X, Vector2_new_ret.Y, v36.Y);
        end;

        if u13 then
            if u10.alpha > 0 and u2.Settings.CameraFlash then
                u10.alpha = u2.rng:NextNumber(0.1, 0.5);
            end;

            u11.Rotation = u2.RNG:NextNumber(-5, 5);
        end;
    end,

    clearUp = function() -- Line: 200, Name: clearUp
        -- upvalues: u10 (ref), u11 (ref)
        for _, v in { u10, u11 } do
            if v ~= nil then
                v:Destroy();
            end;
        end;
    end
};