-- Decompiled with Potassium's decompiler.

return "{\"song\":{\"events\":[[138782.608695652,[[\"Play Animation\",\"HAAAAAANK\",\"dad\"]]]]}}";