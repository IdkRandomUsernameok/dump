-- Decompiled with Potassium's decompiler.

game:GetService("ReplicatedStorage");
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = {
    L = {},
    R = {}
};
local u6 = {};
local u7 = {};

function switchAnim(p8, p9)
    -- upvalues: u2 (ref)
    for _, v in u2[p8] do
        v:LoadAnim(p9);
    end;
end;

function swapIcon(p10, p11, p12, p13)
    -- upvalues: u1 (ref)
    if u1.Settings.UseSongIcons then
        u1.loadIcon(p10, p11, p12, p13);
    end;
end;

function findAnim(p14)
    -- upvalues: u6 (ref)
    for _, v in u6 do
        if v:FindFirstChild("Animations") and v.Animations:FindFirstChild(p14) then
            return v.Animations:FindFirstChild(p14);
        end;

        if v:FindFirstChild("Emotes") and v.Emotes:FindFirstChild(p14) then
            return v.Emotes:FindFirstChild(p14);
        end;
    end;

    return nil;
end;

function spawnBot(p15, ...)
    -- upvalues: u1 (ref), u7 (copy)
    local v16 = findAnim(p15);
    local v17 = u1.spawnBot(v16, ...);

    if v17 then
        v17:PreloadAnim(v16);
        v17:LoadAnim(p15);
    end;

    u7[p15] = v17;

    return v17;
end;

function playEvent(p18, p19)
    -- upvalues: u2 (ref)
    u2[p18].Character:Play(p19);
end;

return {
    onCreate = function(p20) -- Line: 64, Name: onCreate
        -- upvalues: u1 (ref), u2 (ref), u4 (ref), u6 (ref), u5 (copy), u3 (ref)
        u1 = p20;
        u2 = u1.getCharacters();
        u4 = u1.getBackground();
        u6 = { u4.instance };

        for i, v in u2 do
            local v21 = v;

            for _, v2 in u5[i] do
                local v22 = findAnim(v2);

                if v22 ~= nil then
                    for _, v3 in v21 do
                        v3:PreloadAnim(v22);
                    end;
                end;
            end;
        end;

        local v23 = findAnim("Hank - HELLCLOWN");
        u3 = spawnBot("Hank - HELLCLOWN", "R", 90, false, 0);
        u3:PreloadAnim(v23);
        u3:LoadAnim("Hank - HELLCLOWN");
    end
};