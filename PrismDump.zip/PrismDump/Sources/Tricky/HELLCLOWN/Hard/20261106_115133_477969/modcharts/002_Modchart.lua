-- Decompiled with Potassium's decompiler.

local v1 = {};
local u2 = nil;
local u3 = nil;
local u4 = 0;

function v1.onCreate() -- Line: 8
    -- upvalues: u2 (ref), u3 (ref)
    u2 = shared.getApi();
    u3 = u2.Conductor;
end;

function v1.onBeatHit(p5) -- Line: 13
    -- upvalues: u4 (ref), u3 (ref)
    if p5 < 0 then
        return;
    end;

    u4 = u4 + 1;

    if u4 == 95 then
        u3.StepsPerBeat = 7;

        return;
    end;

    if u4 == 122 then
        u3.StepsPerBeat = 4;

        return;
    end;

    if u4 == 198 then
        u3.StepsPerBeat = 7;

        return;
    end;

    if u4 == 287 then
        u3.StepsPerBeat = 9;

        return;
    end;

    if u4 == 324 then
        u3.StepsPerBeat = 5;

        return;
    end;

    if u4 == 400 then
        u3.StepsPerBeat = 7;
    end;
end;

function v1.onOpponentNoteHit(p6) -- Line: 32
    -- upvalues: u2 (ref)
    if p6.side == "L" then
        u2.triggerEvent("Screen Shake", "0.2,0.02", "0,0");
    end;
end;

function v1.onPlayerNoteHit(p7) -- Line: 38
    -- upvalues: u2 (ref)
    if p7.side == "L" then
        u2.triggerEvent("Screen Shake", "0.2,0.02", "0,0");
    end;
end;

return v1;