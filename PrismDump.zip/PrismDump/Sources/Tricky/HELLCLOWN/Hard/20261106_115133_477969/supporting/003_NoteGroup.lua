-- Decompiled with Potassium's decompiler.

return {
    onNote = function(p1) -- Line: 2, Name: onNote
        if p1.rawData[2] > 7 then
            p1.texture = "TrickyMine";
            p1.textureFallback = "LeatherHurtNotes";
            p1.hitCausesMiss = true;
            p1.ignoreNote = true;
            p1.shouldBeHitted = false;
            p1.hitbox = 0.5;
            p1.hitHealth = -0.75;
            p1.hitSound = "rbxassetid://15995931947";
            p1.hitSoundVolume = 1.4;
        end;
    end
};